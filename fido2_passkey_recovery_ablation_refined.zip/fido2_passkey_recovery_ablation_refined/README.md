# Peer-Assisted FIDO2 Passkey Recovery: Hardening Ablation Study

Exhaustive 512-configuration Tamarin ablation campaign over nine preprocessor switches for the enterprise peer-assisted FIDO2 passkey recovery model under the eventually compromised server (ECS) model.

## Repository Contents

- `3_ECS_FIDO2PasskeyRecovery_Ablation.spthy` — unified Tamarin theory parameterised by nine `#ifdef` switches (SHA-256 `cad789b8673fdaff1f5804594a1a3cf0ace37e84c648ce744365ea3ec8a7b2b3`).
- `FIDO2_Passkey_Recovery.oracle` — goal-ranking oracle.
- `fido2_passkey_recovery_ablation_test_v2_runbook.sh` and `fido_ablation_run.log` — campaign driver script and master execution log (`MemoryMax=200G`, swap disabled).
- `ablation_results/prove/` — `manifest.tsv`, configuration and summary tables (`combinations.tsv`, `runs.csv`, `lemmas.csv`), and the 512 per-configuration run records (`.log`, `.rc`, `.time`).

*Note:* Header comments in `3_ECS_FIDO2PasskeyRecovery_Ablation.spthy` name Tamarin 1.10.0; the campaign was executed under Tamarin 1.12.0 and Maude 3.4, as recorded in `ablation_results/prove/manifest.tsv`.
