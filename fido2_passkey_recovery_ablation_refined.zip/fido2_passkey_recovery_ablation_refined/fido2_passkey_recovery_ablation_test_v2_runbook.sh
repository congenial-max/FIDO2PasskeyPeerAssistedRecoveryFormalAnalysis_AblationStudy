#!/usr/bin/env bash
# =============================================================================
# runbook.sh -- full-powerset ablation of 3_ECS_FIDO2PasskeyRecovery_Ablation.spthy
#
# One Tamarin run per subset of the N measure macros (2^N runs), ordered by
# subset size k = 0..N. Combination name: k<k>_<bits>_<codes>, bit i = MACROS[i].
#   <run_dir>/<name>/<name>.spthy   proof object written by --output
#   <run_dir>/<name>/<name>.log     prover stdout + stderr
#   <run_dir>/<name>/<name>.time    /usr/bin/time -v report
#   <run_dir>/<name>/<name>.rc      exit code of the timed command
#   <run_dir>/{manifest.tsv,combinations.tsv,runs.csv,lemmas.csv}
# <run_dir> = <outdir>/prove, or <outdir>/wellformedness with --wellformedness-only.
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)" || exit 1
cd -- "$SCRIPT_DIR" || exit 1

# Local environment: Maude binary in ~/bin and its shared libraries (libgmpxx etc.) in user-space lib_ext.
LIB_EXT="/home/ubuntu-kr-6-antigravity/Desktop/CASE_FOR_MULTI_issuance_base/lib_ext"
export PATH="/home/ubuntu-kr-6-antigravity/bin:$PATH"
export LD_LIBRARY_PATH="$LIB_EXT/usr/lib/x86_64-linux-gnu:$LIB_EXT/usr/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LC_ALL=C.UTF-8
MAUDE_BIN="/home/ubuntu-kr-6-antigravity/bin/maude"
MEMORY_MAX="200G"

THEORY="3_ECS_FIDO2PasskeyRecovery_Ablation.spthy"
ORACLE="FIDO2_Passkey_Recovery.oracle"
TAMARIN="${TAMARIN:-tamarin-prover}"
GNU_TIME="${GNU_TIME:-/usr/bin/time}"

# Canonical order: bit i of a mask <-> MACROS[i] <-> CODES[i]
MACROS=(
  MEASURE_ROLE_SEPARATION
  MEASURE_INTEGRITY_CHECK
  MEASURE_QR_NONCE_BINDING
  MEASURE_RESPONSE_NONCE_CHECK
  MEASURE_MESSAGE_TAGS
  MEASURE_PEER_ID_BINDING
  MEASURE_FRESH_SHARE_SPLIT
  MEASURE_EXPLICIT_PEER_DECRYPTION
  MEASURE_OPEN_REGISTRATION
)
CODES=(ROLE INTEG QRNONCE RESPNONCE TAGS PEERID FRESHSHARE PEERDEC OPENREG)

# Prover flags of commandsForTerminal.txt; --prove and --output=<file> are added per run.
PROVER_FLAGS=(
  "--with-maude=$MAUDE_BIN"
  --with-dot=./tamarin-cleandot.py
  --derivcheck-timeout=0
  --saturation=1000
  --open-chains=1000
  --quit-on-warning
)

JOBS=1
TIMEOUT_S=0
OUTDIR="ablation_results"
RTS_THREADS=""
FORCE=0
WF_ONLY=0
DRY_RUN=0
COLLECT_ONLY=0

usage() {
  cat <<EOF
Usage: ${0##*/} [options]
  -j, --jobs N               concurrent Tamarin runs (default 1; N>1 perturbs time/memory figures)
  -t, --timeout SECONDS      per-run wall-clock limit via timeout(1); 0 = none (default)
  -o, --outdir DIR           results root (default: ablation_results)
  -n, --rts-threads N        append +RTS -N<N> -RTS to every Tamarin call
      --force                re-run combinations that already completed with exit code 0
      --wellformedness-only  parse + wellformedness-check every combination (no --prove)
      --dry-run              print the commands without executing them
      --collect-only         rebuild runs.csv and lemmas.csv from existing results
  -h, --help                 show this text
Environment: TAMARIN (default: tamarin-prover), GNU_TIME (default: /usr/bin/time)
EOF
}

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
log() { printf '[%s] %s\n' "$(date '+%F %T')" "$*"; }
need_arg() { [[ $# -ge 2 && -n "$2" ]] || die "option $1 requires a value"; }

while (($#)); do
  case "$1" in
    -j | --jobs) need_arg "$@"; JOBS="$2"; shift 2 ;;
    -t | --timeout) need_arg "$@"; TIMEOUT_S="$2"; shift 2 ;;
    -o | --outdir) need_arg "$@"; OUTDIR="$2"; shift 2 ;;
    -n | --rts-threads) need_arg "$@"; RTS_THREADS="$2"; shift 2 ;;
    --force) FORCE=1; shift ;;
    --wellformedness-only) WF_ONLY=1; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    --collect-only) COLLECT_ONLY=1; shift ;;
    -h | --help) usage; exit 0 ;;
    *) usage >&2; die "unknown option: $1" ;;
  esac
done

[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || die "--jobs must be a positive integer"
[[ "$TIMEOUT_S" =~ ^[0-9]+$ ]] || die "--timeout must be a non-negative integer"
[[ -z "$RTS_THREADS" || "$RTS_THREADS" =~ ^[1-9][0-9]*$ ]] || die "--rts-threads must be a positive integer"

N=${#MACROS[@]}
((${#CODES[@]} == N)) || die "MACROS and CODES differ in length"
TOTAL=$((1 << N))

if ((WF_ONLY)); then RUN_DIR="$OUTDIR/wellformedness"; else RUN_DIR="$OUTDIR/prove"; fi

# One folder per combination: <RUN_DIR>/<name>/{<name>.spthy, <name>.log, <name>.time, <name>.rc}
combo_paths() {
  CDIR="$RUN_DIR/$1"
  proof="$CDIR/$1.spthy"
  logf="$CDIR/$1.log"
  timef="$CDIR/$1.time"
  rcf="$CDIR/$1.rc"
}

# ----------------------------------------------------------------- powerset
POPCOUNT=()
for ((m = 0; m < TOTAL; m++)); do
  c=0
  x=$m
  while ((x > 0)); do
    c=$((c + (x & 1)))
    x=$((x >> 1))
  done
  POPCOUNT[m]=$c
done
ORDERED=()
for ((k = 0; k <= N; k++)); do
  for ((m = 0; m < TOTAL; m++)); do
    if ((POPCOUNT[m] == k)); then ORDERED+=("$m"); fi
  done
done

combo_name() {
  local m=$1 i k=0 bits="" label=""
  for ((i = 0; i < N; i++)); do
    if (((m >> i) & 1)); then
      bits+="1"
      k=$((k + 1))
      label+="${label:++}${CODES[i]}"
    else
      bits+="0"
    fi
  done
  printf 'k%d_%s_%s' "$k" "$bits" "${label:-NONE}"
}

combo_defines() {
  local m=$1 i out=""
  for ((i = 0; i < N; i++)); do
    if (((m >> i) & 1)); then out+="${out:+ }-D${MACROS[i]}"; fi
  done
  printf '%s' "$out"
}

# --------------------------------------------------- /usr/bin/time -v fields
time_field() {
  [[ -f "$1" ]] || return 0
  awk -v key="$2: " 'index($0, key) { sub(/^[ \t]+/, ""); print substr($0, length(key) + 1); exit }' "$1"
}

to_seconds() {
  awk -v t="$1" 'BEGIN { n = split(t, p, ":"); s = 0; for (i = 1; i <= n; i++) s = s * 60 + p[i]; if (n > 0) printf "%.2f", s }'
}

# ------------------------------------------------------------------ checks
check_inputs() {
  local m
  [[ -f "$THEORY" ]] || die "$THEORY not found in $SCRIPT_DIR"
  [[ -f "$ORACLE" ]] || die "$ORACLE not found in $SCRIPT_DIR"
  for m in "${MACROS[@]}"; do
    grep -q -- "$m" "$THEORY" || die "$m does not occur in $THEORY"
  done
  while IFS= read -r m; do
    [[ " ${MACROS[*]} " == *" $m "* ]] || die "$THEORY uses $m, which is not listed in MACROS"
  done < <(grep -o 'MEASURE_[A-Z][A-Z_]*' "$THEORY" | sort -u)
}

check_tools() {
  command -v "$TAMARIN" >/dev/null 2>&1 || die "'$TAMARIN' not found (set TAMARIN=/path/to/tamarin-prover)"
  if [[ " ${PROVER_FLAGS[*]} " != *" --with-maude="* ]]; then
    command -v maude >/dev/null 2>&1 || die "maude not found in PATH"
  fi
  [[ -x "$GNU_TIME" ]] || die "$GNU_TIME not found (GNU time is required)"
  "$GNU_TIME" -v -o /dev/null true >/dev/null 2>&1 || die "$GNU_TIME does not accept -v -o (GNU time is required)"
  command -v sha256sum >/dev/null 2>&1 || die "sha256sum not found"
  if ((TIMEOUT_S > 0)); then
    command -v timeout >/dev/null 2>&1 || die "timeout(1) not found"
  fi
  if ((JOBS > 1)) && ((BASH_VERSINFO[0] < 4 || (BASH_VERSINFO[0] == 4 && BASH_VERSINFO[1] < 3))); then
    die "--jobs > 1 requires bash >= 4.3"
  fi
  if [[ ! -x "$ORACLE" ]]; then
    chmod u+x -- "$ORACLE" || die "cannot set the executable bit on $ORACLE"
    log "set executable bit on $ORACLE"
  fi
}

sha() { sha256sum -- "$1" | cut -d' ' -f1; }

check_manifest() {
  local mf="$RUN_DIR/manifest.tsv" key old new
  [[ -f "$mf" ]] || return 0
  ((FORCE)) && return 0
  for key in theory oracle; do
    old="$(awk -F'\t' -v k="${key}_sha256" '$1 == k { print $2 }' "$mf")"
    if [[ "$key" == theory ]]; then new="$(sha "$THEORY")"; else new="$(sha "$ORACLE")"; fi
    if [[ -n "$old" && "$old" != "$new" ]]; then
      die "$key file changed since the results in $RUN_DIR were produced; use --force or a new --outdir"
    fi
  done
}

write_manifest() {
  {
    printf 'started_utc\t%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    printf 'host\t%s\n' "$(uname -a)"
    printf 'cpus_online\t%s\n' "$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf unknown)"
    printf 'tamarin\t%s\n' "$("$TAMARIN" --version 2>&1 | head -n 4 | tr '\n\t' '  ')"
    printf 'maude\t%s\n' "$(maude --version 2>&1 | head -n 1)"
    printf 'theory\t%s\n' "$THEORY"
    printf 'theory_sha256\t%s\n' "$(sha "$THEORY")"
    printf 'oracle\t%s\n' "$ORACLE"
    printf 'oracle_sha256\t%s\n' "$(sha "$ORACLE")"
    if ((WF_ONLY)); then printf 'mode\twellformedness-only\n'; else printf 'mode\tprove\n'; fi
    printf 'prover_flags\t%s\n' "${PROVER_FLAGS[*]}"
    printf 'jobs\t%s\n' "$JOBS"
    printf 'timeout_s\t%s\n' "$TIMEOUT_S"
    printf 'rts_threads\t%s\n' "${RTS_THREADS:-tamarin default}"
    printf 'measures\t%s\n' "${MACROS[*]}"
    printf 'codes\t%s\n' "${CODES[*]}"
    printf 'combinations\t%s\n' "$TOTAL"
  } >"$RUN_DIR/manifest.tsv"
}

write_combinations() {
  local seq=0 mask
  printf 'seq\tname\tdefines\n' >"$RUN_DIR/combinations.tsv"
  for mask in "${ORDERED[@]}"; do
    seq=$((seq + 1))
    printf '%d\t%s\t%s\n' "$seq" "$(combo_name "$mask")" "$(combo_defines "$mask")" >>"$RUN_DIR/combinations.tsv"
  done
}

# -------------------------------------------------------------- execution
kill_tree() {
  local child
  for child in $(pgrep -P "$1" 2>/dev/null); do kill_tree "$child"; done
  kill -TERM "$1" 2>/dev/null
}

on_signal() {
  trap '' INT TERM
  log "signal received; terminating running Tamarin processes"
  local p
  for p in $(jobs -p); do kill_tree "$p"; done
  wait 2>/dev/null
  exit 130
}

run_combo() {
  local mask=$1 seq=$2 name proof logf timef rcf rc i CDIR
  local -a defs=() cmd=()
  name="$(combo_name "$mask")"
  combo_paths "$name"
  for ((i = 0; i < N; i++)); do
    if (((mask >> i) & 1)); then defs+=("-D${MACROS[i]}"); fi
  done

  if ((!FORCE && !DRY_RUN)) && [[ -s "$proof" && -f "$rcf" && "$(<"$rcf")" == 0 ]]; then
    log "[$seq/$TOTAL] skip  $name (completed earlier with exit code 0)"
    return 0
  fi

  cmd=(systemd-run --user --scope --quiet -p "MemoryMax=$MEMORY_MAX" -p MemorySwapMax=0)
  cmd+=("$GNU_TIME" -v -o "$timef")
  if ((TIMEOUT_S > 0)); then cmd+=(timeout --signal=TERM --kill-after=60 "$TIMEOUT_S"); fi
  cmd+=("$TAMARIN" ${defs[@]+"${defs[@]}"} "$THEORY")
  if ((!WF_ONLY)); then cmd+=(--prove); fi
  cmd+=("${PROVER_FLAGS[@]}" "--output=$proof")
  if [[ -n "$RTS_THREADS" ]]; then cmd+=(+RTS "-N$RTS_THREADS" -RTS); fi

  if ((DRY_RUN)); then
    printf '%q ' "${cmd[@]}"
    printf '>%q 2>&1\n' "$logf"
    return 0
  fi

  mkdir -p -- "$CDIR" || die "cannot create $CDIR"
  rm -f -- "$proof" "$timef" "$rcf"
  log "[$seq/$TOTAL] start $name"
  "${cmd[@]}" >"$logf" 2>&1 </dev/null &
  wait "$!"
  rc=$?
  printf '%d\n' "$rc" >"$rcf"
  log "[$seq/$TOTAL] done  $name exit=$rc wall=$(time_field "$timef" 'Elapsed (wall clock) time (h:mm:ss or m:ss)') max_rss_kb=$(time_field "$timef" 'Maximum resident set size (kbytes)')"
  return 0
}

# --------------------------------------------------------------- results
collect() {
  local runs="$RUN_DIR/runs.csv" lemmas="$RUN_DIR/lemmas.csv"
  local re='^[[:space:]]+([A-Za-z0-9_]+) \((all-traces|exists-trace)\): (.*) \(([0-9]+) steps\)'
  local seq=0 ok=0 failed=0 missing=0
  local mask name k bits label proof logf timef rcf rc ptime line
  printf 'seq,k,bits,label,defines,exit_code,tamarin_processing_time_s,wall_clock_s,user_s,system_s,cpu_percent,max_rss_kb,proof,log,time_report\n' >"$runs"
  printf 'seq,k,bits,label,lemma,trace_quantifier,result,steps\n' >"$lemmas"
  for mask in "${ORDERED[@]}"; do
    seq=$((seq + 1))
    name="$(combo_name "$mask")"
    IFS=_ read -r k bits label <<<"$name"
    k=${k#k}
    combo_paths "$name"
    if [[ -f "$rcf" ]]; then rc="$(<"$rcf")"; else rc="not_run"; fi
    case "$rc" in
      0) ok=$((ok + 1)) ;;
      not_run) missing=$((missing + 1)) ;;
      *) failed=$((failed + 1)) ;;
    esac
    ptime=""
    if [[ -f "$logf" ]]; then
      ptime="$(sed -n 's/^[[:space:]]*processing time:[[:space:]]*\([0-9.]*\)s.*$/\1/p' "$logf" | head -n 1)"
    fi
    printf '%d,%d,%s,%s,"%s",%s,%s,%s,%s,%s,%s,%s,"%s","%s","%s"\n' \
      "$seq" "$k" "$bits" "$label" "$(combo_defines "$mask")" "$rc" "$ptime" \
      "$(to_seconds "$(time_field "$timef" 'Elapsed (wall clock) time (h:mm:ss or m:ss)')")" \
      "$(time_field "$timef" 'User time (seconds)')" \
      "$(time_field "$timef" 'System time (seconds)')" \
      "$(time_field "$timef" 'Percent of CPU this job got' | tr -d '%')" \
      "$(time_field "$timef" 'Maximum resident set size (kbytes)')" \
      "$proof" "$logf" "$timef" >>"$runs"
    [[ -f "$logf" ]] || continue
    while IFS= read -r line; do
      if [[ "$line" =~ $re ]]; then
        printf '%d,%d,%s,%s,%s,%s,"%s",%s\n' "$seq" "$k" "$bits" "$label" \
          "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}" "${BASH_REMATCH[4]}" >>"$lemmas"
      fi
    done < <(grep -E '^[[:space:]]+[A-Za-z0-9_]+ \((all-traces|exists-trace)\): ' "$logf")
  done
  log "collected $TOTAL combinations: exit 0 = $ok, non-zero = $failed, not run = $missing"
  log "tables: $runs, $lemmas"
  ((failed == 0 && missing == 0))
}

# ------------------------------------------------------------------- main
check_inputs
mkdir -p -- "$RUN_DIR" || die "cannot create $RUN_DIR"

if ((COLLECT_ONLY)); then
  collect
  exit $?
fi

if ((!DRY_RUN)); then
  check_tools
  check_manifest
  write_manifest
  write_combinations
fi

trap on_signal INT TERM
log "theory=$THEORY measures=$N combinations=$TOTAL jobs=$JOBS timeout_s=$TIMEOUT_S run_dir=$RUN_DIR"

seq=0
for mask in "${ORDERED[@]}"; do
  seq=$((seq + 1))
  if ((JOBS > 1 && !DRY_RUN)); then
    while (($(jobs -rp | wc -l) >= JOBS)); do wait -n; done
    run_combo "$mask" "$seq" &
  else
    run_combo "$mask" "$seq"
  fi
done
wait

((DRY_RUN)) && exit 0
collect
